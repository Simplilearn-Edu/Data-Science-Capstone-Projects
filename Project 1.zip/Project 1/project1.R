train<- read.csv(file.choose(),header = T)

dim(train)
library(dplyr)
train <- select(train,-c('BLOCKID'))
dim(train)
## option 1
dim(train[!is.na(train$hc_mortgage_mean),])
## option 2
library(tidyr)
dim(drop_na_(train,'hc_mortgage_mean'))

train_clean <- drop_na_(train,'hc_mortgage_mean')
dim(train_clean)
  
missing_data_column<-colnames(train_clean)[colSums(is.na(train_clean)) > 0]


for (j in missing_data_column){ 
  train_clean[is.na(train_clean[j]),j] <- median(train_clean[,j],na.rm=T)
}

term <-'second_mortgage'
df_pop <- train_clean[train_clean$pct_own >0.1,
                      c('second_mortgage','place','lat','lng','pct_own','pop','state')]

df_sort <- df_pop[order(df_pop$second_mortgage,decreasing = T),]

df_plot <- df_sort[1:2500,]
df_plot$text <- paste(df_plot$place,' ',term,' ',
                         as.character( round(df_plot$second_mortgage*100,4)), '% ')
df_plot$text
df_plot['x']<-1:2500
library(sf)
library(raster)
library(dplyr)
library(spData)
library(tmap)    # for static and interactive maps
library(leaflet) # for interactive maps
library(mapview) # for interactive maps
library(ggplot2) # tidyverse vis package
library(shiny)  

library(leaflet)
pal <- colorNumeric("RdYlBu", domain = df_plot$x)
leaflet(data = df_plot) %>%
  addPolygons(data = us_states, fill = FALSE,weight = 1) %>%
  addCircleMarkers(data = df_plot,
                   radius = 2,col= ~pal(x),opacity = 0.5,
                   label = df_plot$text) %>%
  addLegend(pal = pal, values = df_plot$x)


## calculate Bad debt and good debt
train_clean$bad_debt <- train_clean$second_mortgage + train_clean$home_equity- train_clean$home_equity_second_mortgage
train_clean$good_debt <- train_clean$debt-train_clean$bad_debt

## calculate nodebt = 1- debt
train_clean$no_debt<- 1 - train_clean$debt

mean_data<-colMeans(select_if(train_clean, is.numeric))

label<- c('second mortgage','Home Equity Loan')
flds <- c('second_mortgage','home_equity','home_equity_second_mortgage')
term <- c('10','01','11')

length(levels(as.factor(train_clean$city)))
dim(train_clean)

train_clean$city<-sapply(train_clean$city,trimws)

train_clean$city<-sapply(train_clean$city,tolower)

## data to plot

city_count <- as.data.frame(table(train_clean$city))
city_count <- city_count[order(city_count$Freq,decreasing = T),]
rownames(city_count)<-NULL
head(city_count)
bad_cities <- city_count[city_count$Freq <25,"Var1"]



length(bad_cities)

flds  <- c('city','second_mortgage','home_equity_cdf','bad_debt','good_debt','pop')
fldp <- c('second_mortgage','home_equity_cdf','good_debt','bad_debt')
colr <- c('pink','green','orange','lightblue')
dim(train)
dim(train_clean[train_clean$pct_own >0.1,flds])

## group and filter data
df_city <- train_clean[train_clean$pct_own >0.1,flds]%>%
  group_by(city)%>%
  summarise_all(funs(mean))
df_city <- as.data.frame(df_city)
df_city_2 <- df_city[!df_city$city %in% bad_cities,]

k <- 1
par(mfrow=c(2,2))
for (i in fldp){
  df_city_order <-df_city_2[order(df_city_2[,i],decreasing = T),]
  gg <- df_city_order$city[1:5]
  dt_sub <- train_clean[train_clean$city %in% gg,c(i,'city')]
  dt_plot <- dt_sub[1:5,]
  graphics::boxplot(dt_sub[,i] ~ dt_sub$city ,data = dt_sub, horizontal = T,main = i, notch = F,
                    col = colr[k],
                    names = gg,las = T)
  k <- k+1
  
}
#### Create a collated income distribution chart for family income, 
#### house hold income and remaining income. 
# break down the three categories into basic equations

noDebt <- train_clean$no_debt * train_clean$hc_mean
goodDebt <- train_clean$good_debt * train_clean$hc_mortgage_median
badDebt <- train_clean$bad_debt * train_clean$hc_mortgage_median


train_clean$hc_feature <- goodDebt + noDebt + badDebt
home_costs <- as.array(train_clean$hc_feature *12)
rent_costs <- as.array(train_clean$rent_median *12)


rent_adj_inc<- train_clean$family_median - rent_costs
home_adj_inc <- train_clean$hi_median - home_costs
pct_own <- train_clean$pct_own
x <- 1-train_clean$pct_own
pct_rent <- as.array(x)



# save remaining income and remaining costs
length(home_adj_inc)
a<-pct_own*home_adj_inc
b <- pct_rent*rent_adj_inc

train_clean$rem_income <- a + b
c<-pct_own*home_costs
d <- pct_own*home_costs
train_clean$rem_costs <- c+d


# fields to create plots
flds <- c('family_median','rem_income','hi_median')
lis <- list()
k <- 1
plt_df <- data.frame(cat = '',USDollars = 0)
dim(plt_df)
for (i in flds){
  lis[[k]]<- data.frame(cat = i ,USDollars = train_clean[,i])
  k <- k+1
  plt_df <- rbind(plt_df,data.frame(cat = i ,USDollars = train_clean[,i]))
  
}
dim(plt_df)
plt_df<-plt_df[(!plt_df$cat == '')& (!is.na(plt_df$USDollars)),]
ggplot(plt_df, aes(USDollars, fill = cat)) + 
  geom_density(alpha = 0.2)

train_clean$pop_density <- train_clean$pop / train_clean$ALand
# calculate average median age
t_male_yrs<- train_clean$male_age_median * train_clean$male_pop
t_female_yrs  <- train_clean$female_age_median * train_clean$female_pop 
a <- t_male_yrs + t_female_yrs
b <- train_clean$male_pop + train_clean$female_pop
train_clean$age_median <- a/b


#Create bins for population into a new variable by selecting appropriate 
#class interval so that the no of categories(bins) don’t exceed 5 for the ease of analysis. Analyze the married, separated and divorced population for these population brackets. 
#Visualize using appropriate chart type.

range(train_clean$pop)
par(mfrow = c(1,2))
boxplot(train_clean$pop, horizontal = T)
plot(density(train_clean$pop))


#Looking at these plots we can create follwing brackets
#- 0 to 3500
#- 3500 to 7000
#- 7000 to 10500
#- 10500 to 30000
#- 30000 +
  
func <- function(x){
  ifelse(x<3500,'upto 3500',
         ifelse(x < 7000,'3500 to 7000' ,
                ifelse(x < 10500,'7000 to 10500',
                       ifelse(x < 30000, '10500 to 30000',
                              '30000 and above'))))
}
train_clean$pop_class <- sapply(train_clean$pop,func)
train_clean$pop_married <- train_clean$pop *train_clean$married
train_clean$pop_divorced <- train_clean$pop *train_clean$divorced
train_clean$pop_separated <- train_clean$pop *train_clean$separated
train_clean$pop_married_snp <- train_clean$pop * train_clean$married_snp

## creating for one... 
flds <- c('pop_married','pop_divorced','pop_separated','pop_married_snp')
plt_df <- train_clean[,c('pop_class', flds)]
library(gridExtra)

grid.arrange(
  ggplot(plt_df, aes(pop_married, fill = pop_class)) + 
    geom_density(alpha = 0.2),
ggplot(plt_df, aes(pop_divorced, fill = pop_class)) + 
  geom_density(alpha = 0.2),
ggplot(plt_df, aes(pop_separated, fill = pop_class)) + 
  geom_density(alpha = 0.2),
ggplot(plt_df, aes(pop_married_snp, fill = pop_class)) + 
  geom_density(alpha = 0.2),
ncol =  2)




## Please detail your observations for rent as a percentage 
## of income at an overall level and for different states.
# data we wish to analize:
flds  <- c('city','hi_median','family_median','rent_median','pop')
fldp  <-c('hi_median','rent_median','family_median')

city_count <- as.data.frame(table(train_clean$city))
city_count <- city_count[order(city_count$Freq,decreasing = T),]
bad_cities <- city_count[city_count$Freq <50,"Var1"]
## group and filter data
df_city <- train_clean[,flds]%>%
  group_by(city)%>%
  summarise_all(funs(mean))
df_city <- as.data.frame(df_city)
df_city_2 <- df_city[!df_city$city %in% bad_cities,]
dim(df_city_2)
k <- 1
par(mfrow=c(1,3))
for (i in fldp){
  df_city_order <-df_city_2[order(df_city_2[,i],decreasing = T),]
  gg <- df_city_order$city[1:5]
  dt_sub <- train_clean[train_clean$city %in% gg,c(i,'city')]
  dt_plot <- dt_sub[1:5,]
  graphics::boxplot(dt_sub[,i] ~ dt_sub$city ,data = dt_sub, horizontal = F,main = i, notch = F,
                    col = colr[k],
                    names = gg,las = T)
  k <- k+1
  
}
cols_names <- c('rent_gt_10', 'rent_gt_15', 'rent_gt_20', 'rent_gt_25', 'rent_gt_30', 'rent_gt_35', 'rent_gt_50','family_median', 'hc_mortgage_median', 'hc_median', 'rent_median', 'rem_income','rem_costs', 
                 'married', 'married_snp','hs_degree','hs_degree_male','hs_degree_female','female_age_median','male_age_mean','married','married_snp','pct_own','second_mortgage',
                'home_equity')
names(train_clean)
for (i in cols_names){if (!(i %in% names(train_clean))){print(i)}}


## Perform correlation analysis for all the relevant variables by creating a heatmap. Describe your findings. 
data_corr <- train_clean[,cols_names]
funcs<- function(x){sum(is.na(x))}

cor(data_corr)
library(corrplot)
corrplot(cor(data_corr),method = 'circle',type = 'lower',title="variables correlation Overview")


#The economic multivariate data has a significant number of measured variables. The goal is to find where the measured variables depend on a number of smaller unobserved common factors or latent variables. Each variable is assumed to depend on a linear combination of the common factors, and the coefficients are known as loadings. Each measured variable also includes a component due to independent random variability, known as "specific variance" because it is specific to one variable. Obtain the common factors and then plot the loadings. Use factor analysis to find latent variables in our dataset and gain insight into the linear relationships in the data
#1.	Highschool graduation rates
#2.	Median population age
#3.	Second Mortgage Statistics
#4.	Percent Own
#5.	Bad Debt Expense
data_var <- c('hs_degree','age_median','second_mortgage',
              'pct_own','bad_debt')


plt_pc_df <- train_clean[,data_var]
library(FactoMineR)
result <- PCA(plt_pc_df)
