#1.	Try and explore the data to check for missing values/erroneous entries and also comment on redundant features and add additional ones, if needed.

train_2 <- read.csv(file.choose(),header = T)

dim(train_2)
summary(train_2$Age)

#2.	It is immediately apparent that some of the column names have typos, so let us clear them up 
#   before continuing further, so that we don't have to use alternate spellings every time we need 
#   a variable. 
library(data.table)
setnames(train_2, old=c('ApointmentData', 'Alcoolism', 'HiperTension', 'Handcap'), 
         new=c('AppointmentData', 'Alchoholism', 'Hypertension', 'Handicap'))
names(train_2)


#3.	For convenience, convert the AppointmentRegistration and Appointment 
#   columns into datetime format and the AwaitingTime column into absolute values.

library(lubridate)

train_2$AppointmentRegistration<-ymd_hms(train_2$AppointmentRegistration)
train_2$AppointmentData <- ymd_hms(train_2$AppointmentData)

train_2$AwaitingTime <- abs(train_2$AwaitingTime)

#4.	Create a new feature called HourOfTheDay, which will indicate the hour of the day at which the appointment was booked. 
calhr <- function(x){
  as.POSIXlt(x)$hour 
}
train_2['HourOfTheDay'] <- sapply(train_2$AppointmentRegistration, calhr)

#5.	Identify and remove outliers from Age. Explain using an appropriate plot.
summary(train_2$Age)
train_2<- train_2[(train_2$Age >= 0 & train_2$Age <= 95),]
summary(train_2$Age)
plot(density(train_2$Age))

#6.	Analyse the probability of showing up with respect to different features. 
# Create scatter plot and trend lines to analyse the relation between probability of showing up 
# with respect to age/Houroftheday/awaitingtime. Describe your finding.

prob_plot_data <- function(x, var){
  t <-table(x[,var],x$Status)
  df <-data.frame(group = rownames(t),No_show = t[,1],Show_up = t[,2] ,
             Prob_show_up = t[,2]/(t[,1]+t[,2]))
  colnames(df)[colnames(df)=='group']<-var
  df[,c(var,'Prob_show_up')]
}

# option 1
par(mfrow = c(1,3))
for (v in c('Age',"HourOfTheDay",'AwaitingTime')){d <- prob_plot_data(train_2,v)
d[v] <- sapply(d[v],as.numeric)
plot(d[v], 
     d$Prob_show_up, 
     xlab = v, ylab = "Prob", 
     type = 'p',
     main = sprintf('%s',v),
     col = 'darkblue'
     
     )
abline(lm(d$Prob_show_up~d[,v]),col='dark green', lw = 3)}


## option 2
vec <- c('Age',"HourOfTheDay",'AwaitingTime')
for (v in vec ){
d <- prob_plot_data(train_2,v)
d[v] <- sapply(d[v],as.numeric)

pl<- ggplot(d,aes_string(x = v, y = 'Prob_show_up')) + 
  geom_point() +
  stat_smooth(method = "lm", col = "red")
print(pl)
}


#7.	Create a bar graph to depict probability of showing up for 
#  diabetes, alcoholism, hypertension, TB, smokes, scholarship.

data<-matrix(nrow = 2, ncol = 6)
colnames(data)=dat
rownames(data)=c(0,1)
dat <- c('Diabetes', 'Alchoholism', 'Hypertension',
         'Tuberculosis', 'Smokes', 'Scholarship')
for (v in dat){ 
  t<-table(train_2[,v],train_2[,'Status'])
  for ( col in 1:2){
    showup <- round(t[col,2]/sum(t[col,]),2)
    data[col,v] <- showup
  }}
barplot(data, beside = TRUE, col = colors()[c(2,3)])



#8.	Create separate bar graphs to show the probability of showing up for 
# male and female, 
#and sms reminder. Describe your interpretation. 
data<-matrix(nrow = 1, ncol = 2)
colnames(data)=levels(train_2$Gender)
t<-table(train_2[,'Gender'],train_2[,'Status'])
t
for ( col in 1:2){
  showup <- round(t[col,2]/sum(t[col,]),2)
  data[,col]<- showup
}
barplot(data, beside = TRUE, col = colors()[c(2,3)])

##Handicap
data<-matrix(nrow = 1, ncol =length(levels(as.factor(train_2$Handicap))) )
colnames(data)=levels(as.factor(train_2$Handicap))
t<-table(train_2[,'Handicap'],train_2[,'Status'])
t
for ( col in 1:ncol(data)){
  showup <- round(t[col,2]/sum(t[col,]),2)
  data[,col]<- showup
}
data
barplot(data, beside = TRUE, col = colors()[c(2,3)])

#DayOfTheWeek

data<-matrix(nrow = 1, ncol =length(levels(as.factor(train_2[,'DayOfTheWeek']))) )
colnames(data)=levels(as.factor(train_2[,'DayOfTheWeek']))
t<-table(train_2[,var],train_2[,'Status'])
t
for ( col in 1:ncol(data)){
  showup <- round(t[col,2]/sum(t[col,]),2)
  data[,col]<- showup
}
data
barplot(data, beside = TRUE, col = colors()[c(2,3)])



